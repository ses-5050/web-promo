
function myFunction() {
    var x = document.getElementById("myDIV");
    x.querySelector(".example").innerHTML = "Hello World!";
  }


   